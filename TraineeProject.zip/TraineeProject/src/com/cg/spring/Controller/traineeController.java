package com.cg.spring.Controller;

import java.util.ArrayList;

import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.spring.entities.Trainee;
import com.cg.spring.service.TraineeService;
import com.cg.spring.userlogin.userLogin;

@Controller
public class traineeController {
	
	@Autowired
	TraineeService service;
	
	@RequestMapping("/LoginPage")
	public String validate(Model model)
	{
		userLogin user = new userLogin();
		model.addAttribute("userBean", user);
		return "index";
	}
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String validateCredentials(@ModelAttribute("userBean")userLogin bean,Model model){
		
			if(bean.getUserName().equals("capgemini") && bean.getPassword().equals("corp@123"))
			{
				return "showList";
			}
			else
			{
				model.addAttribute("message", "Invalid User Name and Password");
				return "error";
			}
	}
	@RequestMapping("/addTrainee")
	public String showAddTrainee(Model model){
		Trainee trainee = new Trainee();
		model.addAttribute("traine", trainee);
		return "addTrainee";
	}
	
	@RequestMapping("/addTraineeDetails")
	public String addTraineeDetails(@ModelAttribute ("traine")Trainee trainee,Model model)
	{
		System.out.println(trainee);
		int id = service.addTrainee(trainee);
		System.out.println(id);
		return "showList";
	}
	
	@RequestMapping("/deleteTrainne")
	public String delShow(Model model)
	{
		Trainee trainee = new Trainee();
		model.addAttribute("id", trainee);
		return "delete";
	}
	@RequestMapping("/deleteTrainee")
	public String deleteTrainnee(@ModelAttribute ("id") Trainee id,Model model)
	{
		int res= service.deleteTraine(id);
		if(res!=0)
		return "delsuccess";
		else
			return "error";
	}
	@RequestMapping("/modifyTrainee")
	public String modifyShow(Model model)
	{
		Trainee trainee = new Trainee();
		model.addAttribute("id", trainee);
		return "modify";
	}
	@RequestMapping("/modifytrainee")
	public String fetchrecord(@ModelAttribute ("id") Trainee id,Model model)
	{
		Trainee record = service.fetchRecord(id);
		model.addAttribute("record", record);
		return "modify1";
	}
	@RequestMapping("/updateDetails")
	public String updateDetails(@ModelAttribute ("record")Trainee record,Model model)
	{
		service.updateRecord(record);
		return "showList";
	}
	@RequestMapping("/singleTrainee")
	public String singleRecord(Model model)
	{
		Trainee trainee = new Trainee();
		model.addAttribute("id", trainee);
		model.addAttribute("status",false);
		return "single";
	}
	@RequestMapping("/single")
	public String fetchRecord(@ModelAttribute ("id")Trainee id,Model model)
	{
		Trainee single = service.singleRecord(id);
		model.addAttribute("singleList", single);
		model.addAttribute("status", true);
		return "single";
	}
	@RequestMapping("/allTrainees")
	public String showAll(Model model)
	{
		ArrayList<Trainee> list = service.showAll();
		model.addAttribute("List", list);
		return "showAll";
	}
}
