package com.cg.trainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.dto.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	private ITraineeDao traineeDao;

	@Override
	public void addTrainee(Trainee trainee) {
		
		traineeDao.addTrainee(trainee);
	}

	@Override
	public void updateTrainee(Trainee trainee) {
	
		traineeDao.updateTrainee(trainee);
	}

	@Override
	public void deleteTrainee(String traineeId) {

		traineeDao.deleteTrainee(traineeId);
	}

	@Override
	public Trainee getTrainee(String traineeId) {
		
		return traineeDao.getTrainee(traineeId);
	}

	@Override
	public List<Trainee> getAllTrainees() {
		
		return traineeDao.getAllTrainees();
	}

	public int validate(String name, String password) {
		if (name.equals("teju") && password.equals("momdad")) {
			return 1;
		} else {
			return 0;
		}
	}
}
