package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.dto.Trainee;

public interface ITraineeService {
	void addTrainee(Trainee trainee);

	void updateTrainee(Trainee trainee);

	void deleteTrainee(String traineeId);

	Trainee getTrainee(String traineeId);

	List<Trainee> getAllTrainees();

	public int validate(String name, String password);
}
