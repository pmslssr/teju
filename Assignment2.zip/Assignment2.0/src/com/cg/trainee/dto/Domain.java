package com.cg.trainee.dto;

public enum Domain {
	JEE, DOTNET, MainFrame, PHP;
}
