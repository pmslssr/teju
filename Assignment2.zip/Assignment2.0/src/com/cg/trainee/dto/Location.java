package com.cg.trainee.dto;

public enum Location {
	Chennai, Bangalore, Pune, Mumbai;
}
