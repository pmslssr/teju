package com.cg.trainee.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.dto.Domain;
import com.cg.trainee.dto.Location;
import com.cg.trainee.dto.Trainee;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;

	@RequestMapping("/listTrainees")
	public ModelAndView doListtrainees() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("listTrainnes");
		mv.addObject("title", "TraineeList");
		mv.addObject("trainee", traineeService.getAllTrainees());
		return mv;
	}

	@RequestMapping("/listTraineeOnly")
	public ModelAndView showTrainee(
			@RequestParam(value = "mno", required = false) String traineeId) {

		ModelAndView mv = new ModelAndView();
		Trainee trainee = traineeService.getTrainee(traineeId);
		mv.setViewName("listTraineeOnly");
		mv.addObject("title", "traineeDetail");
		mv.addObject("trainee", trainee);
		return mv;
	}

	@RequestMapping("/newTrainee")
	public ModelAndView showNewContact() {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("newTrainee");
		mv.addObject("title", "NewTrainee");
		mv.addObject("domain", Domain.values());
		mv.addObject("location", Location.values());
		mv.addObject("trainee", new Trainee());
		return mv;
	}

	@RequestMapping("/delete")
	public ModelAndView delete() {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("delete");
		mv.addObject("title", "DeleteTrainee");
		return mv;
	}

	@RequestMapping("/deletebutton")
	public ModelAndView deleteButton(
			@RequestParam(value = "mno", required = true) String traineeId) {
		ModelAndView mv = new ModelAndView();
		if (traineeId != null) {
			Trainee trainee = traineeService.getTrainee(traineeId);
			if (trainee != null) {
				traineeService.deleteTrainee(traineeId);
				mv = doListtrainees();
			} else {
				mv.addObject("msg", "No Such trainee id found");
			}
		}
		return mv;
	}

	@RequestMapping("/saveTrainee")
	public ModelAndView doSaveTrainee(
			@Valid @ModelAttribute("trainee") Trainee trainee,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv.setViewName("newTrainee");
			mv.addObject("title", "Newtrainee");
			mv.addObject("trainee", trainee);
		} else {
			traineeService.addTrainee(trainee);
			mv = doListtrainees();
		}
		return mv;
	}

	@RequestMapping("/searchTrainee")
	public ModelAndView doSearchTrainee(
			@RequestParam(value = "mno", required = false) String traineeId) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("searchTrainee");
		mv.addObject("title", "SearchTrainee");

		if (traineeId != null) {
			Trainee trainee = traineeService.getTrainee(traineeId);
			if (trainee != null)
				mv.addObject("trainee", trainee);
			else
				mv.addObject("msg", "No Such contact");
		}
		return mv;
	}

	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(
			@RequestParam(value = "mno", required = false) String traineeId) {
		ModelAndView mv = new ModelAndView();
		if (traineeId != null) {
			traineeService.deleteTrainee(traineeId);
			mv.addObject("title", "DeleteTrainee");
			mv = doListtrainees();
		}
		return mv;
	}

	@RequestMapping("/editTrainee")
	public ModelAndView editTrainee(
			@RequestParam(value = "mno", required = false) String traineeId) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("editTrainee");
		mv.addObject("location", Location.values());
		mv.addObject("domain", Domain.values());
		mv.addObject("title", "ModifyTrainee");
		Trainee trainee = traineeService.getTrainee(traineeId);
		mv.addObject("trainee", trainee);
		return mv;
	}

	@RequestMapping("/saveEditedTrainee")
	public ModelAndView doSearchContact1(
			@Valid @ModelAttribute("contact") Trainee trainee,
			BindingResult result) {
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv.setViewName("editContact");
			mv.addObject("title", "saveEditedContact");
			mv.addObject("trainee", trainee);
		} else {
			// contactService.deleteContact(mobileNumber);
			traineeService.updateTrainee(trainee);
			mv = doListtrainees();
		}
		return mv;
	}
}
