package com.cg.trainee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.service.ITraineeService;

@Controller
public class HomeController {

	@Autowired
	private ITraineeService traineeService;

	@RequestMapping(value = { "", "/", "/index" })
	public ModelAndView showLogin() {
		return new ModelAndView("login", "title", "Login");
	}

	@RequestMapping("/menus")
	public String showMenus() {
		return "menus";
	}

	@RequestMapping("/home")
	public String showHome() {
		return "home";
	}

	@RequestMapping("/head")
	public String showHead() {
		return "head";
	}

	@RequestMapping("/login")
	public ModelAndView login(
			@RequestParam(value = "name", required = true) String name,
			@RequestParam(value = "pass", required = true) String password) {
		ModelAndView mv = new ModelAndView();
		int val = traineeService.validate(name, password);
		if (val == 1) {
			mv.setViewName("home");
			mv.addObject("title", "Home");
		} else {
			mv.setViewName("login");
			mv.addObject("msg", "LoginFailed");
		}
		return mv;
	}
}
