package com.hotel.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Hotel")
public class HotelBean {
	
	
@Id
private int hotelId;


@NotEmpty(message="Please Enter Hotel Name")
@Pattern(regexp = "^[a-zA-Z /s]+$", message = "Hotel Name must contain only alphabets")
	private String hotelName;
 
@NotEmpty(message="Please Enter the city Name")
@Pattern(regexp = "^[a-zA-Z]+$", message = "City Name must contain only alphabets")
	private String city;


	private String lunchTime;
	
	
	private char bookingStatus;


	public int getHotelId() {
		return hotelId;
	}


	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}


	public String getHotelName() {
		return hotelName;
	}


	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getLunchTime() {
		return lunchTime;
	}


	public void setLunchTime(String lunchTime) {
		this.lunchTime = lunchTime;
	}


	public char getBookingStatus() {
		return bookingStatus;
	}


	public void setBookingStatus(char bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	
	
	
	
	
	
}
